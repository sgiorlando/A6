The link to view my website is: http://sgiorlando.github.io/A6/index.html

or you could also use: http://sgiorlando.github.io/A6/sgiorlan_assign6.html

To download all my files you can use: http://sgiorlando.github.io/A6/sgiorlan_assign6.zip